package model;

public class UserDetail {
	
	private String userName;
	private String mailId;
	private String fullName;
	private String status;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public UserDetail() {
			}
	public UserDetail(String userName, String mailId, String fullName) {
		super();
		this.userName = userName;
		this.mailId = mailId;
		this.fullName = fullName;
	}
	@Override
	public String toString() {
		return "UserDetail [userName=" + userName + ", mailId=" + mailId + ", fullName=" + fullName + ", status="
				+ status + "]";
	}
	

}
