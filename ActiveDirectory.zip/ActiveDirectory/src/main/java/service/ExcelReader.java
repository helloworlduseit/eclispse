package service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelReader {


	static List<String> userIdsList = new ArrayList<String>();

	public static List getUserIds(String SAMPLE_XLSX_FILE_PATH) throws IOException, InvalidFormatException{

		Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));

		// Getting the Sheet at index zero
		Sheet sheet = workbook.getSheetAt(0);

		// Create a DataFormatter to format and get each cell's value as String
		DataFormatter dataFormatter = new DataFormatter();
		/*	Row  firstRow = sheet.getRow(0);
			Cell firstCell = firstRow.getCell(0);
			String firstCellValue = dataFormatter.formatCellValue(firstCell);
			if(firstCellValue.equalsIgnoreCase("UserName")){

				for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
					Row  row = sheet.getRow(rowIndex);

					if (row != null) {
						int colIndex = 0;
						Cell cell = row.getCell(colIndex);
						if (cell != null) {
							String cellValue = dataFormatter.formatCellValue(cell);					
								userIdsList.add(cellValue);									
						}
					}
				}				
			}*/

		String cellValue = null;
		int userColumnIndex =0;
		for (Row row: sheet) {
			for(Cell cell: row) {
				if(cell != null){
					cellValue = dataFormatter.formatCellValue(cell);
				}
				if(cellValue.equalsIgnoreCase("USER NAME")){

					userColumnIndex = cell.getColumnIndex();

				}	
				if( cell.getColumnIndex()== userColumnIndex  && cell.getRowIndex()>0){

					userIdsList.add(cellValue);	

					//System.out.print(cellValue + "\n");	

				}


			}


		}

		workbook.close();

		return userIdsList;

	}

}
