package service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.formula.functions.Columns;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import model.UserDetail;

public class ExcelWriter {

	public static void writeUserDetails(List<UserDetail> userdetails) throws IOException{
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("UserDetails");
		// List<UserDetail> userDetails =  new ArrayList<>();
		int rowCount = 0;
		Row row = sheet.createRow(rowCount);
		row.createCell(0)
		.setCellValue("USER ID");

		row.createCell(1)
		.setCellValue("FULL NAME");

		row.createCell(2)
		.setCellValue("MAIL ID");
		
		row.createCell(3)
		.setCellValue("STATUS");

		for (UserDetail detail : userdetails) {
			row = sheet.createRow(++rowCount);

			row.createCell(0)
			.setCellValue(detail.getUserName());

			row.createCell(1)
			.setCellValue(detail.getFullName());

			row.createCell(2)
			.setCellValue(detail.getMailId());
			
			row.createCell(3)
			.setCellValue(detail.getStatus());
		}
		int totalRows=sheet.getLastRowNum();
		// Resize all columns to fit the content size
		for(int i = 0; i < totalRows; i++) {
			sheet.autoSizeColumn(i);
		}
		FileOutputStream fileOut = new FileOutputStream("UserDetails.xlsx");
		workbook.write(fileOut);
		fileOut.close();

		// Closing the workbook
		workbook.close();


	}
	

}
