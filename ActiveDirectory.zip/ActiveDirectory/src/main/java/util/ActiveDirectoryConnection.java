package util;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import model.UserDetail;

public class ActiveDirectoryConnection {
	static DirContext ldapContext;
	
	
	public static UserDetail retrieveUserDetails(String hubId){
		 UserDetail user = null;
		try
		{
			
			//System.out.println("------Testing Active Directory access in Java------");

			Hashtable<String, String> ldapEnv = new Hashtable<String, String>(11);
			ldapEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			ldapEnv.put(Context.PROVIDER_URL,  "ldap://wdw.disney.com:389");	
			ldapEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
			ldapEnv.put(Context.SECURITY_PRINCIPAL, "CN=app-rtuid,OU=ServiceAccounts,OU=DMTP,DC=wdw,DC=disney,DC=com");
			ldapEnv.put(Context.SECURITY_CREDENTIALS, "D1$NeY6595");
			ldapContext = new InitialDirContext(ldapEnv);

			// Create the search controls         
			SearchControls searchCtls = new SearchControls();

			//Specify the attributes to return

			String returnedAtts[]={"sn","givenName", "samAccountName","mail","name","description","userPrincipalName","cn"};
			searchCtls.setReturningAttributes(returnedAtts);

			//Specify the search scope
			searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

			//specify the LDAP search filter
			String searchFilter = "(&(&(objectClass=person)(objectCategory=user))(sAMAccountName=" + hubId + "))";
			//String searchFilter = "(&(&(objectClass=person)(objectCategory=user))(sn=" + hubId + "))";
			//Specify the Base for the search
			String searchBase = "dc=wdw,dc=disney,dc=com";
			//initialize counter to total the results


			// Search for objects using the filter
			NamingEnumeration<SearchResult> answer = ldapContext.search(searchBase, searchFilter, searchCtls);
			//Loop through the search results
			while (answer.hasMoreElements())
			{
				SearchResult sr = (SearchResult)answer.next();


				//System.out.println(">>>" + sr.getName());
				Attributes attrs = sr.getAttributes();
				
				user=new UserDetail(attrs.get("samAccountName").get(0).toString(),
						attrs.get("mail").get(0).toString(),attrs.get("name").get(0).toString());
				/*System.out.println("- " + attrs.get("samAccountName"));
				System.out.println("- " + attrs.get("givenName"));
				System.out.println("- " + attrs.get("userPrincipalName"));
				System.out.println("- Mail ID: "+ attrs.get("mail").get(0).toString());
				System.out.println("- "+ attrs.get("name"));
				System.out.println("- "+ attrs.get("description"));
				System.out.println("- Surname/ "+ attrs.get("sn"));
				System.out.println("- Common Name:  "+ attrs.get("cn").get(0).toString());*/


			}


			ldapContext.close();

		}
		catch(NullPointerException ex){
			user=new UserDetail("NULL","NULL","NULL");
		}
		catch (Exception e)
		{
			System.out.println(" Search error: " + e);
			e.printStackTrace();
			System.exit(-1);
		}
		
		return user;

	}


}
