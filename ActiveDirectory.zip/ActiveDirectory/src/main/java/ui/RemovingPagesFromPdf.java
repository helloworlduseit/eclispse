package ui;

import java.io.File; 
import java.io.IOException;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;  

public class RemovingPagesFromPdf { 
   public static void main(String args[]) throws IOException, COSVisitorException {  
      
      //Loading an existing document 
      File file = new File("C:/Users/manej016/Downloads/test.pdf"); 
      PDDocument doc = PDDocument.load(file); 
       
      //Listing the number of existing pages       
      System.out.print(doc.getNumberOfPages()); 
       
      for(int i = 0; i<5; i++){
         
         //removing the pages 
         doc.removePage(i); 
      } 
      System.out.println("page removed");       
      
      //Saving the document 
      doc.save("C:/Users/manej016/Downloads/RemovePages_OP.pdf");     
      
      //Closing the document  
      doc.close(); 
   }  
} 