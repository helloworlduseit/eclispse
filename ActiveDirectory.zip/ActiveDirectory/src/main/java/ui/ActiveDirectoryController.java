package ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import model.UserDetail;
import service.ExcelReader;
import service.ExcelWriter;
import util.ActiveDirectoryConnection;

public class ActiveDirectoryController {
	
	
	private static final String SAMPLE_XLSX_FILE_PATH = "./src/main/resources/actual.xlsx";

	//private static final String SAMPLE_XLSX_FILE_PATH = "C:/Disney Account/Work Done/Active User Directory/actual.xlsx";
	private static List<UserDetail> userDetails =  new ArrayList<UserDetail>();
	public static void main(String[] args) throws InvalidFormatException, IOException {
		UserDetail user=new UserDetail();


		List<String> userIdsList = new ArrayList<String>();
		//	ActiveDirectoryConnection.getActiveDirectoryConnection();
		//try {

			userIdsList = ExcelReader.getUserIds(SAMPLE_XLSX_FILE_PATH);
			System.out.println("> Data is Pulled from Excel sheet Successfully\n");
			for (String str : userIdsList) {	

				System.out.println(str);
				user=ActiveDirectoryConnection.retrieveUserDetails(str);
				if(user==null)
				{
					user=new UserDetail(str,"NULL","NULL");
					user.setStatus("INACTIVE");
					
				}
				else{
					user.setStatus("ACTIVE");
				}
				
				userDetails.add(user);				
				
				//System.out.println("\n"+user.toString());		
			}
			System.out.println("> User details validated from Active Directory\n");
			ExcelWriter.writeUserDetails(userDetails);
			System.out.println("> User Details written into excel file\n");


		/*} catch (InvalidFormatException | IOException e) {

			e.printStackTrace();
		}*/

	}

}
